<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "12345678";
$dbname = "breast_cancer";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if prediction data is received
if (isset($_POST['prediction'])) {
    // Sanitize the prediction data
    $prediction = $conn->real_escape_string($_POST['prediction']);

    // Insert prediction data into the database table
    $sql = "INSERT INTO predictions (prediction) VALUES ('$prediction')";
    if ($conn->query($sql) === TRUE) {
        echo "Prediction data inserted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
