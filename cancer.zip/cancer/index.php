<?php
header("Location: predict.php");
?>
